﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace PracticeM4
{
    public partial class DeleteStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
                SqlCommand cmd = new SqlCommand("delete from College_172477 where HallTicketNumber=@HallTicketNumber", con);
                cmd.Parameters.AddWithValue("@HallTicketNumber", txthallti.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                txthallti.Text = null;
               // Response.Redirect("HomePage.aspx");
               // Response.Write("<script type='text/javascript'>alert('record deleted Successfully');</script>");
                Server.Transfer("HomePage.aspx");
            }
            catch (Exception ex)
            {

                throw ex;
            }
           
        }
    }
}