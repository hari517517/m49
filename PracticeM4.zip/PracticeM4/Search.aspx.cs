﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace PracticeM4
{
    public partial class Search : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtstuname.Visible = false;
            txtage.Visible = false;
            txtemail.Visible = false;
            lblage.Visible = false;
            lblemailid.Visible = false;
            lblstuname.Visible = false;
            btnupdate.Visible = false;

        }

        protected void btnsearch_Click(object sender, EventArgs e)

        {
            txtstuname.Visible =true;
            txtage.Visible =true;
            txtemail.Visible =true;
            lblage.Visible = true ;
            lblemailid.Visible =true;
            lblstuname.Visible =true;
            btnupdate.Visible = true;

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
            SqlCommand cmd = new SqlCommand("select HallTicketNumber,StudentName,Age,EmailID from College_172477 where HallTicketNumber=@HallTicketNumber ", con);
            cmd.Parameters.AddWithValue("@HallTicketNumber", txthallnumber.Text);
            con.Open();

            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                txthallnumber.Text = dr["HallTicketNumber"].ToString();
                txtstuname.Text = dr["StudentName"].ToString();
                txtage.Text = dr["Age"].ToString();
                txtemail.Text = dr["EmailID"].ToString();

            }
            con.Close();


           
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
            SqlCommand cmd = new SqlCommand("update College_172477 set StudentName=@StudentName,Age=@Age,EmailID=@EmailID where HallTicketNumber=@HallTicketNumber ", con);
            cmd.Parameters.AddWithValue("@HallTicketNumber", txthallnumber.Text);
            cmd.Parameters.AddWithValue("@StudentName", txtstuname.Text);
            cmd.Parameters.AddWithValue("@Age", txtage.Text);
            cmd.Parameters.AddWithValue("@EmailID",txtemail.Text);
            con.Open();
          int record=  cmd.ExecuteNonQuery();
            if (record>0)
            {
                Response.Write("<script type='text/javascript'>alert('record Updated Successfully');</script>");
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('record Not Updated');</script>");
            }
            con.Close();

            //Response.Redirect("HomePage.aspx");

            Server.Transfer("HomePage.aspx");

        }
    }
}