﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace PracticeM4
{
    public partial class AddStudent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
                SqlCommand cmd = new SqlCommand("insert into College_172477 values(@HallTicketNumber,@StudentName,@Age,@Gender,@DateOFBirth,@Skills,@EmailID,@PreferedSubject)", con);

                cmd.Parameters.AddWithValue("@HallTicketNumber", txthallnumber.Text);
                cmd.Parameters.AddWithValue("@StudentName", txtstuname.Text);
                cmd.Parameters.AddWithValue("@Age", txtage.Text);
                
                string gender = string.Empty;
                if (rbmale.Checked)
                {
                    gender = "male";
                }
                if (rbfemale.Checked)
                {
                    gender = "female";
                }
               

                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@DateOFBirth",txtdob.Text);

                string skills = string.Empty;
                if(cbjava.Checked)
                {
                    skills = "Java";
                }
                if (cbDotnet.Checked)
                {
                    skills = skills+"," +"DotNet";

                }
                if (cbc.Checked)
                {
                    skills = skills +","+ "C";
                }
                cmd.Parameters.AddWithValue("@Skills",skills);

                cmd.Parameters.AddWithValue("@EmailID", txtemail.Text);
                cmd.Parameters.AddWithValue("@PreferedSubject", dropsub.Text);
                con.Open();
                int recordEffected = cmd.ExecuteNonQuery();
                con.Close();
                if (recordEffected>0)
                {
                    Response.Write("<script type='text/javascript'>alert('record added Successfully');</script>");
                }
                else
                {
                    Response.Write("<script type='text/javascript'>alert('record not added added ');</script>");
                }
            }
            catch (Exception ex)
            {
                

                Response.Write(ex.Message);
            }

            //txthallnumber.Text = null;
            //txtstuname.Text = null;
            //txtage.Text = null;
            //txtemail.Text = null;

            //txtdob.Text = null;

            //dropsub.Text = null;


            Server.Transfer("HomePage.aspx");
           //Response.Redirect("");
        }

        
    }
}